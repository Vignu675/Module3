package com.capg;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

@SuppressWarnings("deprecation")
public class TestApp {
	
	public static void main (String[] args) {
		
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("application.xml"));
			
		ApplicationContext context=new FileSystemXmlApplicationContext("C:\\test\\Hybernate\\SpringWelcomeApp\\src\\application.xml");
		
		Employee emp = factory.getBean("emp", Employee.class); //2nd para is to typecasting
		Address a= factory.getBean("addr",Address.class);
		
		System.out.println(a);
		System.out.println(emp.getSkills());
		System.out.println(emp.getProjects());
		System.out.println(emp.getTeamMates());
		
		System.out.println(emp);
		System.out.println(emp.getAddress().getCity());
		System.out.println("By autowiring--"+ emp.getAddress());

	}
	

}
