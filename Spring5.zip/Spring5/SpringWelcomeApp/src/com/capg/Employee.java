package com.capg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

public class Employee {

	private int eid;
	private String ename;
	private double salary;
	private Address address;
	
	private Properties teamMates;
	
	private ArrayList<String> skills;
	
	private HashMap<Integer,String> projects;
	

	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public ArrayList<String> getSkills() {
		return skills;
	}
	public void setSkills(ArrayList<String> skills) {
		this.skills = skills;
	}
	public HashMap<Integer, String> getProjects() {
		return projects;
	}
	public void setProjects(HashMap<Integer, String> projects) {
		this.projects = projects;
	}
	public Properties getTeamMates() {
		return teamMates;
	}
	public void setTeamMates(Properties teamMates) {
		this.teamMates = teamMates;
	}
	
	
	
	
	
	
	
}
