package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	
	@RequestMapping("/")
	public ModelAndView sayHello(){
		Employee emp = new Employee();
		
		emp.setEid(10);
		emp.setEname("Vignesh");
		emp.setSalary(50000);
		
		ModelAndView mv= new ModelAndView("index","emp",emp);
		
		//mv.addObject("emp",emp);  Option 1
		//mv.setViewName("index");
		
		
		return mv;
	}

}
