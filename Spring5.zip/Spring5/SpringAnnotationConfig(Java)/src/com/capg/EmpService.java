package com.capg;

import org.springframework.stereotype.Service;

@Service("s1")
public class EmpService {
	
}
