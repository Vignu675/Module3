package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Client {

	@Autowired
	static EmpService service;
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
	
		context.scan("com.capg");
		context.refresh();
		
		/*Employee emp = context.getBean("emp",Employee.class);
		Employee emp2 = context.getBean("emp",Employee.class);
		emp.setEname("Vignesh");
		System.out.println(emp.getAddress());
		System.out.println(emp2);
*/
	}
	/*
		@Bean(name="e1")
	public Employee getEmpObj() {  //User creating object without IOC(Config+Bean Annotation)
		return new Employee();
	}*/

}
