package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Product;
import com.capg.service.IProductService;

@RestController
public class ProductController {

	
	@Autowired
	IProductService service;
	
	// Getting All Products
	@GetMapping(value="/products", produces="application/json")
	public List<Product> getAllProducts(){
		
		return service.getAllProducts();
	}
	
	
	//Adding New Product
	@PostMapping(value="/addProduct",consumes="application/json")
	public ResponseEntity<String> addProduct(@Valid @RequestBody Product product) {
        service.addProduct(product);
        return new ResponseEntity<String>("Product Added.",HttpStatus.OK);
    }
	
	
	//Updating Existing Product
	@PutMapping(value="/updateProduct",consumes="application/json")
	public ResponseEntity<String> updateProduct(@RequestBody Product product) {
        service.updateProduct(product);
        return new ResponseEntity<String>("Product Updated.",HttpStatus.OK);
    }
	
	
	//Deleting Specific Product By Id
	@DeleteMapping(value="/delete/{pid}",produces="application/json")
	public ResponseEntity<String> deleteProductById(@PathVariable int pid) {
		service.deleteProductById(pid);
		 return new ResponseEntity<String>("Product Deleted.",HttpStatus.OK);
	}
	
}
