package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Product;
import com.capg.dao.ProductDao;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	ProductDao repo;
	
	
	@Override
	public List<Product> getAllProducts() {
		
		return repo.findAll();
	}


	@Override
	public void addProduct(Product product) {
		
		repo.save(product);
		
	}


	@Override
	public Product updateProduct(Product product) {
		return repo.save(product);
		
	}


	@Override
	public void deleteProductById(int pid) {
		
		 repo.deleteById(pid);
		
	}
	
	

	

}
