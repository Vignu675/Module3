package com.capg.service;

import java.util.List;

import com.capg.bean.Product;

public interface IProductService {

	List<Product> getAllProducts();

	void addProduct(Product product);

	Product updateProduct(Product product);

	void deleteProductById(int pid);

}
