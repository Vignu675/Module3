insert into product_masters values(1,'LAPTOP',50000,9988776655);
insert into product_masters values(2,'MOBILE',17000,9700123456);
insert into product_masters values(3,'AC',34000,8877994433);
insert into product_masters values(4,'WASHING MACHINE',23000,9977668844);