package com.capg;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class EmployeeController {
	
	@Autowired
	DAORepository repo;
	
	@RequestMapping(value = "/")
	public String form() {
		return "EmpForm";
	}
	
	@PostMapping(value = "/display")
	public String insert(Employee emp, Model model) {
		model.addAttribute("emp", emp);
		repo.save(emp);
		return "display";
	}
	
	@GetMapping(value = "/getEmployee")
	@ResponseBody
	public String getEmployee(int eid) {
		Employee employee = repo.findById(eid).orElse(null);
		return employee.toString();
	}
	
	@GetMapping(value = "/getAll")
	@ResponseBody
	public String getAll() {
		List<Employee> list = (List<Employee>) repo.findAll();
		return list.toString();
	}

}
