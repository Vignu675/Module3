package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DisplayController {

	@Autowired
	Employee emp;
	
	@RequestMapping(value = "/")
	public String form() {
		return "EmpForm";
	}
	
	
	/*@RequestMapping(value = "/display")
	public String display(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		int eid = Integer.parseInt(request.getParameter("eid"));
		String ename = request.getParameter("ename");
		double salary = Double.parseDouble(request.getParameter("salary"));
		
		emp.setEid(eid);
		emp.setEname(ename);
		emp.setSalary(salary);
		
		session.setAttribute("emp", emp);
		
		return "display";
	}*/
	
	/*@RequestMapping(value = "/display")
	public String display(@RequestParam("eid") int eid, @RequestParam("ename") String ename, @RequestParam("salary") double salary, Model md) {
		
		emp.setEid(eid);
		emp.setEname(ename);
		emp.setSalary(salary);
		
		md.addAttribute("emp", emp);
		
		return "display";
	}*/
	
	@PostMapping(value = "/display")
	public ModelAndView display(Employee emp) {
		
		ModelAndView mv =new ModelAndView();
		mv.addObject("emp", emp);
		mv.setViewName("display");
		
		return mv;
	}
	
}
