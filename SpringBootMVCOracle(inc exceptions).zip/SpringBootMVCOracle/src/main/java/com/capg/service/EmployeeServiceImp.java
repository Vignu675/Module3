package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import com.capg.bean.Employee;
import com.capg.dao.EmployeeRepository;

@Service
public class EmployeeServiceImp implements IEmployeeService {

	
	@Autowired
	EmployeeRepository repo;
	
	
	/*@Override
	public Employee getEmployeeById(int eid) {

		return repo.findById(eid).orElse(new Employee());
	}


	@Override
	public List<Employee> getAllEmployees() {

		return repo.findAll();
		
	}


	@Override
	public void delEmployeeById(int eid) {
		
		 repo.deleteById(eid);
	}*/
	
	
	@Override
	public Employee getEmployeeById(int eid) {

		return repo.findById(eid).orElse(new Employee());
	}


	@Override
	public List<Employee> getAllEmployees() {

		return repo.findAll();
		
	}


	@Override
	public void delEmployeeById(int eid) {
		
		 repo.deleteById(eid);
	}


	@Override
	public Employee addEmployee(Employee emp) {
		return repo.save(emp);
	
	}


	@Override
	public Employee updateEmployee(Employee emp) {
		
		return repo.save(emp);
	}


	@Override
	public List<Employee> getEmployeeBySalary(double salary) {
		
		return repo.findBySalary(salary);
	}


	@Override
	public List<Employee> getEmployeeByRange() {
		
		return repo.findByRange();
	}

}
