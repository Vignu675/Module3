package com.capg;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

		@RequestMapping("/")
		public String sayHello(Model model){
			
			Employee emp = new Employee();
			emp.setEid(101);
			emp.setEname("Shreyash");
			emp.setSalary(4000);
			
			model.addAttribute("emp",emp);
			
			
			
			
			return "index";
		}
}
