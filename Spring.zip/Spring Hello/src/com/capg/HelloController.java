package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {

	@RequestMapping(value = "/display",method = RequestMethod.GET)
	public String display(@RequestParam("uname") String uname,@RequestParam("pwd") String pwd , Model m ){
		
		
		User user = new User();
		user.setName(uname);
		user.setPassword(pwd);
		
		m.addAttribute("user",user);
		return "success";
	} 
	
}
