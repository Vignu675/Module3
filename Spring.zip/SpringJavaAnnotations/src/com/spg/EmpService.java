package com.spg;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
public class EmpService {
	
}
