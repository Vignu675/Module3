package com.spg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;


@Configuration
public class Main {

	@Autowired
	EmpService service;
	
	public static void main(String[] args){
		
		
		
		AnnotationConfigApplicationContext context =new AnnotationConfigApplicationContext();
		
		
		context.scan("com.spg");
		context.refresh();	
		
		Employee emp = context.getBean("emp",Employee.class);
		Employee emp2 = context.getBean("emp",Employee.class);
		emp.setEid(101);
		emp.setEname("Shreyash");
		System.out.println(emp.getAddress());
		System.out.println(emp2);
		/*//EmpService service = context.getBean("s1",EmpService.class);
		//System.out.println("EmpService " +service);
		
		Main m = new Main();
		System.out.println(m.getService());*/
		
	}

	
	
	

	/*@Bean(name= "e1")
	@Scope("prototype")
	public Employee getEmpObj(){
		
		return new Employee();
	}*/
}
