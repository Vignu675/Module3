package com.spg;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class Main {
	public static void main(String[] args){
		
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("Application.xml"));
		
		ApplicationContext context = new FileSystemXmlApplicationContext("C:\\Shreyash_Eclipse\\SpringWelcome\\src\\Application.xml");
			//Address addr = factory.getBean("addr",Address.class);
			//Employee emp = factory.getBean("emp",Employee.class);
		
		Employee emp = context.getBean("emp",Employee.class);
		Employee emp2 = context.getBean("emp",Employee.class);
		System.out.println(emp);
		System.out.println(emp2);
			//System.out.println(addr);
		
		System.out.println(emp.getSkills());
		System.out.println(emp.getProjects());
		System.out.println(emp.getTeamMates());
		System.out.println(emp.getEname());
	}
}
