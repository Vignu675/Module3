package com.spg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

public class Employee {

	
	private int eid;
	private String ename;
	private double salary;
	private Address address;
	
	
	private ArrayList<String> skills;
	private HashMap<Integer,String> projects; 
	private Properties teamMates ;
	
	
	
	public Employee(Address address) {
		super();
		this.address = address;
	}
	
	public Employee(int eid, String ename, double salary) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
	}

	public Properties getTeamMates() {
		return teamMates;
	}
	public void setTeamMates(Properties teamMates) {
		this.teamMates = teamMates;
	}
	public HashMap<Integer, String> getProjects() {
		return projects;
	}
	public void setProjects(HashMap<Integer, String> projects) {
		this.projects = projects;
	}
	public ArrayList<String> getSkills() {
		return skills;
	}
	public void setSkills(ArrayList<String> skills) {
		this.skills = skills;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	
}
