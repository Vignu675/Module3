package com.capg.service;

import java.util.List;

import com.capg.bean.Product;

public interface IProductService {

	public void addProduct(Product product);
	public List<Product> getAll();
}
