package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capg.bean.Product;
import com.capg.service.ProductService;


@Controller
public class ProductController {
	
	
	@Autowired
	ProductService service;
	
	@RequestMapping("/")
	public String addNewProduct() {
		return "login";
	}
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct(Product product){
		
		service.addProduct(product);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("product", product);
		mv.setViewName("display");
		
		return mv;
	}
	
	@RequestMapping("/getAll")
	public ModelAndView getAll(){
		
		List<Product> pro = service.getAll();
		ModelAndView mv = new ModelAndView();
		mv.addObject("product", pro);
		mv.setViewName("displayAll");
		
		return mv;
		
		
		
	}
	
	
	

}
