package com.capg.service;

import java.util.List;

import com.capg.bean.Student;

public interface StudentService {
	
	public void addStudent(Student student);
	public List<Student> getAll();

}
