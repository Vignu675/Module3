package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Student;
import com.capg.dao.StudentDao;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao repository;
	
	@Override
	public void addStudent(Student student) {
		repository.save(student);
	}

	@Override
	public List<Student> getAll() {
		return repository.findAll();
	}

}
