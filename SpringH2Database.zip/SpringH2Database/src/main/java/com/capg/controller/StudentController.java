package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.capg.bean.Student;
import com.capg.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	StudentService service;
	
	@RequestMapping(value="/")
	public String studentForm() {
		return "studentForm";
	}
	
	@PostMapping(value="/addStudent")
	public ModelAndView addstudent(Student student) {
		ModelAndView mv = new ModelAndView();
		service.addStudent(student);
		mv.addObject("student", student);
		mv.setViewName("display");
		return mv;
	}
	
	@GetMapping(value="/getAll")
	public ModelAndView getAll() {
		ModelAndView mv = new ModelAndView();
		List<Student> studentList = service.getAll();
		mv.addObject("student", studentList);
		mv.setViewName("displayAll");
		return mv;
	}
	
}
