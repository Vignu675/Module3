package com.capg.service;

import com.capg.bean.Employee;
import java.util.List;

public interface IEmployeeService {

	
	/*public Employee getEmployeeById(int eid);
	
	public List<Employee> getAllEmployees();

	public void delEmployeeById(int eid);*/
		
	
	public Employee getEmployeeById(int eid);
	
	public List<Employee> getAllEmployees();

	public void delEmployeeById(int eid);
	
	public Employee addEmployee(Employee emp);

	public Employee updateEmployee(Employee emp);
	
	public List<Employee> getEmployeeBySalary(double salary);
	
	
}
