package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Employee;
import com.capg.service.IEmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	IEmployeeService service;
	
	/*@GetMapping("/employee/{eid}")
	public String getEmployeeById(@PathVariable int eid) {
		
		
		Employee emp = service.getEmployeeById(eid);
		
		return emp.toString();
	}
	
	@GetMapping("/employees")
	public String getAllEmployees() {
		
		return service.getAllEmployees().toString();
	}
	
	@DeleteMapping("/employee/{eid}")
	public void deleteEmployeeById(@PathVariable int eid) {
		
		service.delEmployeeById(eid);

	}*/
	
	@GetMapping(path = "/employee/{eid}", produces = "application/json")
	public Employee getEmployeeById(@PathVariable int eid) {
		
		
		Employee emp = service.getEmployeeById(eid);
		
		return emp;
	}
	
	@GetMapping(path = "/employees")
	public List<Employee> getAllEmployees() {
		
		return service.getAllEmployees();
	}
	
	@DeleteMapping(path = "/employee/{eid}", produces = "application/json")
	public void deleteEmployeeById(@PathVariable int eid) {
		
		service.delEmployeeById(eid);

	}
	
	@PostMapping(path = "/employee", consumes = "application/json")
	public Employee addEmployee(@RequestBody Employee emp){
		
		return service.addEmployee(emp);
		
	}
	
	@PutMapping(path = "/employee", consumes = "application/json")
	public Employee updateEmployee(@RequestBody Employee emp) {
		
		return service.updateEmployee(emp);
		
	}
	
	@GetMapping(path = "/employee/sal/{salary}")
	public List<Employee> getEmployeeBySalary(@PathVariable double salary) {
		
		
		List<Employee> list = service.getEmployeeBySalary(salary);
		
		return list;
	}
	
	@GetMapping(path = "/employeerange")
	public List<Employee> getEmployeeByRange() {
		
		
		List<Employee> list = service.getEmployeeByRange();
		
		return list;
	}
	
	
}
