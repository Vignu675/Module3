package com.cg.exception;

public class WithdrawException extends Exception {
	public WithdrawException(String s) {
		System.out.println(s);
	}
}
