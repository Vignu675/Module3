package com.cg.exception;

public class MobileNumberException extends Exception{
	public MobileNumberException(String s)
	{
		System.out.println(s);
	}
}
