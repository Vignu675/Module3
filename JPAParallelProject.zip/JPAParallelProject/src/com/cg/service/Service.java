package com.cg.service;

import com.cg.entities.Account;
import com.cg.entities.Customer;

public interface Service {
	
	public abstract void createCustomerService(Customer customer);
	public abstract Account showBalanceService(int accountNo);
	public abstract void depositService(int depositAccount, double depositAmount);
	public abstract void withdrawService(int withdrawAccount, double withdrawAmount);
	public abstract void fundTransferService(int senderAccountNo, int receiverAccountNo, double transferAmount);

}
